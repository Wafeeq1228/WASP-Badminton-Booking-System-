﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASS_API.DataAccessLayer;
using AutoMapper;
using ASS_API.Models;
using ASS_API.DbModels;
using Microsoft.EntityFrameworkCore;

namespace ASS_API.Reppository_Di
{
    enum STATUS{
        BOOKED,
        CANCELLED
    }
    public class AppointmentRepo : IAppointment
    {
        
        public readonly EfDbContext efDbContext = null;
        public readonly IMapper mapper = null;
        public AppointmentRepo(EfDbContext efDbContext, IMapper mapper)
        {
            this.efDbContext = efDbContext;
            this.mapper = mapper;
        }
        public async Task<int?> BookAppointment(AppointmentSchedulingModel booking, char courtId, int custId, int staffId)
        {
           try
            {
                var check = (from book in efDbContext.Book where (book.Bookstatus == STATUS.BOOKED.ToString() && book.StartTime == booking.StartTime && book.CourtId == courtId) select book).Count();
                if (check < 4)
                {
                    var newBooking = new AppointmentScheduling
                    {
                        BookDate = booking.BookDate,
                        StartTime = booking.StartTime,
                        EndTime = booking.EndTime,
                        Bookstatus = STATUS.BOOKED.ToString(),
                        CustomerId = custId,
                        StaffId = staffId,
                        CourtId = courtId
                    };
                    await efDbContext.Book.AddAsync(newBooking);
                    await efDbContext.SaveChangesAsync();
                    return newBooking.Id;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<int?> CancelAppointment(int bookingId)
        {
            try
            {
                var bookin =await  efDbContext.Book.Where(e=>e.Id==bookingId).FirstOrDefaultAsync();
                if (bookin == null)
                {
                    return null;
                }
                bookin.Bookstatus = STATUS.CANCELLED.ToString();
                await efDbContext.SaveChangesAsync();
                return bookingId;

            }
            catch { return null; }
        }

        public async Task<List<AppointmentSchedulingModel>> GetAllActiveAppointmentDetails(int id)
        {
            var bookingList = from book in efDbContext.Book where book.StartTime > DateTime.Now && book.CustomerId == id && book.Bookstatus == STATUS.BOOKED.ToString() select book;
            return mapper.Map<List<AppointmentSchedulingModel>>(bookingList);
        }

        public async Task<List<AppointmentSchedulingModel>> GetAllAppointmentDetails(int id)
        {
            var list = await efDbContext.Book.Where(e => e.CustomerId == id).ToListAsync();
            return mapper.Map<List<AppointmentSchedulingModel>>(list);

        }

        public async Task<int?> RescheduleAppointment(int bookingId, AppointmentSchedulingModel book)
        {
            try
            {
            
                var bookin = await efDbContext.Book.Where(e => e.Id == bookingId).FirstOrDefaultAsync();
                if (bookin == null)
                {
                    return null;
                }
                bookin.StartTime = book.StartTime;
                bookin.EndTime = book.EndTime;
                bookin.BookDate = book.BookDate;
                await efDbContext.SaveChangesAsync();
                return bookingId;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
