﻿using ASS_API.DataAccessLayer;
using ASS_API.Models;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASS_API.Reppository_Di
{
    public class CourtRepo:ICourt
    {
        private readonly EfDbContext efDbContext;
        private readonly IMapper _mapper;

        public CourtRepo(EfDbContext efDbContext, IMapper mapper)
        {
            this.efDbContext = efDbContext;
            _mapper = mapper;
        }
        public async Task<List<CourtModel>> GetCourtDetails()
        {
            var courtList = await efDbContext.Court.ToListAsync();
            return _mapper.Map<List<CourtModel>>(courtList);

        }
    }
}
