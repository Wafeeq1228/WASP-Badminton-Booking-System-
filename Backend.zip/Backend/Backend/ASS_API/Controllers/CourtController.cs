﻿using ASS_API.Reppository_Di;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourtController : ControllerBase
    {
        private readonly ICourt _court;
        public CourtController(ICourt court)
        {
            _court = court;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetCourtDetails()
        {
            var courtList = await _court.GetCourtDetails();
            return Ok(courtList);
        }
    }
}
